def removeDuplicate(my_list):
    result = []
    for i in my_list:
        if i not in result :
            result.append(i)
    return result

if __name__ =="__main__":

    my_list = [1,2,55,3,2,34,55]
    answer = removeDuplicate(my_list)
    print(answer)

