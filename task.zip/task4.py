input_str = "hello world and practice makes perfect and hello world again"
result = []
string = ""
for i in input_str:
    if i ==" ":
        if string not in result:
            result.append(string)
        string = ""    
    else:
        string = string + i    
result.append(string)

min_no =0

for i in range(0,len(result)):
    min_no = result[i][0]
    for j in range(i+1,len(result)):
        if min_no > result[j]:
            temp = result[j]
            result[j] = result[i]
            result[i] = temp
            min_no = result[i]
            

string = ""
for i in result:
    string = string +" "+ i

print(string)