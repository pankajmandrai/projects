def loweToUpper(string):
    result  = ""
    for i in string:
        if ord(i) >= 97:
           result =  result + chr(ord(i) - 32)
        else:
            result = result + i     
    return result

if __name__ =="__main__":
    x = "Hello world"

    answer = loweToUpper(x)
    print(answer)
