def countInList(list_data):
    result = {}
    for i in list_data:
        if i in result:
            result[i] = result[i] +1
        else: 
            result[i] = 1
    return result        

if __name__ =="__main__":

    my_list = ['python','python3','user1','assignment','user','userr1','python',"User1"]
    answer = countInList(my_list)
    print(answer)