def numberOfChicken(Legs,heads):
    no_rabbit = (legs - heads*2) //2
    no_chicken = (heads - no_rabbit)
    return [no_rabbit,no_chicken]


if  __name__ =="__main__":
    heads = int(input("no. of heads: "))
    legs = int(input("no. of legs: "))
    no_rabbit,no_chicken = numberOfChicken(legs,heads)
    print("no of chicken:",no_chicken,"\nno_rabbit:",no_rabbit) 
