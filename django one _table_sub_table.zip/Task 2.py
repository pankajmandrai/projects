import math
def PrimeFactor(value):

    z = []
    isPrime = True
    temp  = value
    while temp !=1:
        for i in range(2,value):
            
            isPrime = True
            for j in range(2,i):
                if i % j ==0 :
                    isPrime = False
             
            if isPrime and temp % i == 0 :
                temp = temp // i
                
                z.append(i)
                break
    return z

answer  = PrimeFactor(213)

print(answer)
