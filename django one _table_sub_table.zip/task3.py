
def findLargestSquare(M, m, n, maxsize):

	# base condition
	if m == 0 or n == 0:
		return M[m][n], max(maxsize, M[m][n])

	left, maxsize = findLargestSquare(M, m, n - 1, maxsize)
	top, maxsize = findLargestSquare(M, m - 1, n, maxsize)
	diagonal, maxsize = findLargestSquare(M, m - 1, n - 1, maxsize)

	size = 1 + min(min(top, left), diagonal) if M[m][n] else 0
	return size, max(maxsize, size)


if __name__ == '__main__':

	M = [
		[10100],
		[10111],
		[11111],
		[10010],
	
	]

	maxsize = findLargestSquare(M, len(M) - 1, len(M[0]) - 1, 0)[1]
	print("The size of largest square sub-matrix of 1's is", maxsize)
