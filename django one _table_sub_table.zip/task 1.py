def charOccurance(string_data):
    result = {}
    for i in string_data:
        if i in result:
            result[i] = result[i] +1
        else: 
            result[i] = 1
    return result        



answer = charOccurance('abababababbabaab')
for i in answer.keys():
    print("({},{})".format(i,answer[i]),end=" ")
